// ===== إعدادات مشتركة لكل صفحات الموقع =====
// غيّر الرقم ده لو تغيّر البورت بتاع ElecStoreAPI (من launchSettings.json)
const API_BASE_URL = "https://localhost:7140/api";
